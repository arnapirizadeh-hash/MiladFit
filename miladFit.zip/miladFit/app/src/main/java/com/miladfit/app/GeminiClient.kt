package com.miladfit.app

import android.graphics.Bitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Talks to Google Gemini Vision over plain HTTPS (no SDK needed). */
class GeminiClient(private val model: String = BuildConfig.GEMINI_MODEL) {

    suspend fun analyze(bitmap: Bitmap, apiKey: String): NutritionResult = withContext(Dispatchers.IO) {
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray()
                .put(JSONObject().put("text", PROMPT))
                .put(JSONObject().put("inline_data", JSONObject()
                    .put("mime_type", "image/jpeg")
                    .put("data", ImageUtils.toBase64Jpeg(bitmap))))
            )))
            .put("generationConfig", JSONObject()
                .put("temperature", 0.2)
                .put("response_mime_type", "application/json"))

        val conn = (URL("$BASE_URL/$model:generateContent").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            doOutput = true
            connectTimeout = 20_000
            readTimeout = 90_000
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("x-goog-api-key", apiKey)
        }
        try {
            conn.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) {
                val msg = runCatching { JSONObject(text).getJSONObject("error").getString("message") }
                    .getOrDefault("Server error ($code)")
                throw IOException(msg)
            }
            val raw = JSONObject(text).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
            val result = NutritionResult.fromJson(JSONObject(cleanJson(raw)))
            if (!result.isFood) throw IOException("No food detected. Try another photo.")
            result
        } finally {
            conn.disconnect()
        }
    }

    private fun cleanJson(s: String): String =
        s.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()

    companion object {
        private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models"
        private val PROMPT = """
            You are an expert nutritionist and food-recognition AI.
            Analyze the food in this photo. Identify every visible food item, estimate each portion in grams,
            and calculate nutrition for the WHOLE plate exactly as served.
            Respond ONLY with JSON matching this schema:
            {
              "is_food": boolean,
              "food_name": string (short English dish name),
              "description": string (one short English sentence),
              "calories": integer (kcal),
              "protein_g": number, "carbs_g": number, "fat_g": number,
              "fiber_g": number, "sugar_g": number, "sodium_mg": integer,
              "health_score": integer 1-10,
              "confidence": integer 0-100,
              "items": [{"name": string, "grams": integer, "calories": integer}],
              "tip": string (one practical nutrition tip in English)
            }
            If there is no food in the image, set is_food to false and use 0 for all numbers.
        """.trimIndent()
    }
}
