package com.miladfit.app

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Bg = Color(0xFF0B0F1A)
val SurfaceColor = Color(0xFF141A2A)
val Accent = Color(0xFFB6FF3B)
val Accent2 = Color(0xFF3BFFC8)
val ProteinColor = Color(0xFF4FC3F7)
val CarbsColor = Color(0xFFFFB74D)
val FatColor = Color(0xFFFF6B9A)
val TextDim = Color(0xFF9AA3B8)
val ErrorColor = Color(0xFFFF5C5C)

@Composable
fun MiladFitTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent, onPrimary = Color.Black,
            secondary = Accent2, background = Bg, surface = SurfaceColor,
            onBackground = Color.White, onSurface = Color.White,
        ),
        typography = Typography(),
        content = content,
    )
}
