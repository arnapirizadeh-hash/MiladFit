package com.miladfit.app

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

sealed interface UiState {
    data object Idle : UiState
    data class Analyzing(val image: Bitmap) : UiState
    data class Success(val image: Bitmap, val result: NutritionResult) : UiState
    data class Error(val image: Bitmap?, val message: String) : UiState
}

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = Prefs(app)
    private val client = GeminiClient()

    private val _state = MutableStateFlow<UiState>(UiState.Idle)
    val state = _state.asStateFlow()

    val history = mutableStateListOf<HistoryEntry>().apply { addAll(prefs.loadHistory()) }

    var apiKey by mutableStateOf(prefs.apiKey)
        private set

    fun updateApiKey(key: String) {
        apiKey = key.trim()
        prefs.apiKey = apiKey
    }

    fun analyzeUri(uri: Uri) {
        viewModelScope.launch {
            val bmp = runCatching {
                withContext(Dispatchers.IO) { ImageUtils.loadBitmap(getApplication(), uri) }
            }.getOrElse {
                _state.value = UiState.Error(null, "Couldn't open that image.")
                return@launch
            }
            analyze(bmp)
        }
    }

    fun analyze(bitmap: Bitmap) {
        val key = apiKey.ifBlank { BuildConfig.GEMINI_API_KEY }
        if (key.isBlank()) {
            _state.value = UiState.Error(bitmap, "Add your free Gemini API key in Settings first.")
            return
        }
        _state.value = UiState.Analyzing(bitmap)
        viewModelScope.launch {
            runCatching { client.analyze(bitmap, key) }
                .onSuccess { result ->
                    _state.value = UiState.Success(bitmap, result)
                    saveToHistory(bitmap, result)
                }
                .onFailure { e ->
                    _state.value = UiState.Error(bitmap, e.message ?: "Analysis failed. Check your connection.")
                }
        }
    }

    private suspend fun saveToHistory(bitmap: Bitmap, result: NutritionResult) {
        val ts = System.currentTimeMillis()
        val path = withContext(Dispatchers.IO) {
            runCatching { ImageUtils.saveThumbnail(getApplication(), bitmap, ts) }.getOrDefault("")
        }
        history.add(0, HistoryEntry(ts, path, result))
        while (history.size > 100) history.removeAt(history.lastIndex)
        prefs.saveHistory(history.toList())
    }

    fun clearHistory() {
        history.forEach { runCatching { File(it.imagePath).delete() } }
        history.clear()
        prefs.saveHistory(emptyList())
    }

    fun reset() { _state.value = UiState.Idle }
}
