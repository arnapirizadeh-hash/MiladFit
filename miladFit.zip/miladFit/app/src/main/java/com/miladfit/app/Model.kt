package com.miladfit.app

import org.json.JSONArray
import org.json.JSONObject

data class FoodItem(val name: String, val grams: Int, val calories: Int)

data class NutritionResult(
    val isFood: Boolean,
    val foodName: String,
    val description: String,
    val calories: Int,
    val protein: Double,
    val carbs: Double,
    val fat: Double,
    val fiber: Double,
    val sugar: Double,
    val sodiumMg: Int,
    val healthScore: Int,
    val confidence: Int,
    val items: List<FoodItem>,
    val tip: String,
) {
    fun toJson(): JSONObject = JSONObject()
        .put("is_food", isFood)
        .put("food_name", foodName)
        .put("description", description)
        .put("calories", calories)
        .put("protein_g", protein)
        .put("carbs_g", carbs)
        .put("fat_g", fat)
        .put("fiber_g", fiber)
        .put("sugar_g", sugar)
        .put("sodium_mg", sodiumMg)
        .put("health_score", healthScore)
        .put("confidence", confidence)
        .put("tip", tip)
        .put("items", JSONArray().apply {
            items.forEach { put(JSONObject().put("name", it.name).put("grams", it.grams).put("calories", it.calories)) }
        })

    companion object {
        fun fromJson(o: JSONObject): NutritionResult {
            val arr = o.optJSONArray("items")
            val items = if (arr == null) emptyList() else (0 until arr.length()).map { i ->
                val it = arr.getJSONObject(i)
                FoodItem(it.optString("name", "Item"), it.optInt("grams", 0), it.optInt("calories", 0))
            }
            return NutritionResult(
                isFood = o.optBoolean("is_food", true),
                foodName = o.optString("food_name", "Unknown meal"),
                description = o.optString("description", ""),
                calories = o.optInt("calories", 0),
                protein = o.optDouble("protein_g", 0.0),
                carbs = o.optDouble("carbs_g", 0.0),
                fat = o.optDouble("fat_g", 0.0),
                fiber = o.optDouble("fiber_g", 0.0),
                sugar = o.optDouble("sugar_g", 0.0),
                sodiumMg = o.optInt("sodium_mg", 0),
                healthScore = o.optInt("health_score", 5).coerceIn(1, 10),
                confidence = o.optInt("confidence", 70).coerceIn(0, 100),
                items = items,
                tip = o.optString("tip", ""),
            )
        }
    }
}

data class HistoryEntry(val timestamp: Long, val imagePath: String, val result: NutritionResult) {
    fun toJson(): JSONObject = JSONObject()
        .put("ts", timestamp).put("img", imagePath).put("result", result.toJson())

    companion object {
        fun fromJson(o: JSONObject) = HistoryEntry(
            o.getLong("ts"), o.optString("img", ""), NutritionResult.fromJson(o.getJSONObject("result"))
        )
    }
}

/** FDA daily values, used for the "% of daily" bars. */
object DailyGoals {
    const val PROTEIN = 50.0
    const val CARBS = 275.0
    const val FAT = 78.0
    const val CALORIES = 2000
}
