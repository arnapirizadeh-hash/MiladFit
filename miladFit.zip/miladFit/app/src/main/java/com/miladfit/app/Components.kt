package com.miladfit.app

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale
import kotlin.math.roundToInt

fun Double.fmt(): String =
    if (this % 1.0 == 0.0) this.toInt().toString() else String.format(Locale.US, "%.1f", this)

@Composable
fun GlassCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(24.dp)
    Column(
        modifier
            .clip(shape)
            .background(Brush.linearGradient(listOf(Color.White.copy(alpha = 0.09f), Color.White.copy(alpha = 0.03f))))
            .border(1.dp, Color.White.copy(alpha = 0.12f), shape)
            .padding(18.dp),
        content = content
    )
}

@Composable
fun GradientTitle(text: String, fontSize: TextUnit = 40.sp) {
    Text(
        text,
        style = TextStyle(
            brush = Brush.linearGradient(listOf(Accent, Accent2)),
            fontSize = fontSize, fontWeight = FontWeight.Black
        )
    )
}

@Composable
fun PrimaryButton(text: String, icon: ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = modifier.fillMaxWidth().height(58.dp),
        shape = RoundedCornerShape(18.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.Black)
    ) {
        Icon(icon, contentDescription = null)
        Spacer(Modifier.width(10.dp))
        Text(text, fontWeight = FontWeight.Bold, fontSize = 16.sp)
    }
}

@Composable
fun SecondaryButton(text: String, icon: ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit) {
    OutlinedButton(
        onClick = onClick,
        modifier = modifier.fillMaxWidth().height(58.dp),
        shape = RoundedCornerShape(18.dp),
        border = androidx.compose.foundation.BorderStroke(1.5.dp, Accent.copy(alpha = 0.6f)),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = Accent)
    ) {
        Icon(icon, contentDescription = null)
        Spacer(Modifier.width(10.dp))
        Text(text, fontWeight = FontWeight.Bold, fontSize = 16.sp)
    }
}

/** Animated donut: calorie split by macro (protein 4, carbs 4, fat 9 kcal/g). */
@Composable
fun MacroRing(calories: Int, protein: Double, carbs: Double, fat: Double, modifier: Modifier = Modifier, size: Dp = 200.dp) {
    val progress = remember { Animatable(0f) }
    LaunchedEffect(calories) {
        progress.snapTo(0f)
        progress.animateTo(1f, tween(1400, easing = FastOutSlowInEasing))
    }
    val parts = listOf(protein * 4 to ProteinColor, carbs * 4 to CarbsColor, fat * 9 to FatColor)
    val total = parts.sumOf { it.first }.takeIf { it > 0 } ?: 1.0
    Box(modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 18.dp.toPx()
            val inset = stroke / 2 + 4.dp.toPx()
            val arcSize = Size(this.size.width - inset * 2, this.size.height - inset * 2)
            val tl = Offset(inset, inset)
            // fake depth: shadow ring underneath
            drawArc(Color.Black.copy(alpha = 0.35f), 0f, 360f, false, Offset(inset, inset + 6.dp.toPx()), arcSize, style = Stroke(stroke))
            drawArc(Color.White.copy(alpha = 0.07f), 0f, 360f, false, tl, arcSize, style = Stroke(stroke))
            var start = -90f
            val gap = 5f
            parts.forEach { (v, col) ->
                val sweep = ((v / total) * 360f).toFloat() * progress.value
                if (sweep > gap) {
                    drawArc(col, start + gap / 2, sweep - gap, false, tl, arcSize, style = Stroke(stroke, cap = StrokeCap.Round))
                }
                start += sweep
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Filled.LocalFireDepartment, contentDescription = null, tint = Accent)
            Text("${(calories * progress.value).roundToInt()}", fontSize = 42.sp, fontWeight = FontWeight.Black, color = Color.White)
            Text("kcal", color = TextDim, fontSize = 14.sp)
        }
    }
}

@Composable
fun MacroCard(label: String, grams: Double, color: Color, goal: Double, modifier: Modifier = Modifier) {
    val pct = ((grams / goal) * 100).roundToInt()
    GlassCard(modifier) {
        Box(Modifier.size(10.dp).clip(CircleShape).background(color))
        Spacer(Modifier.height(8.dp))
        Text("${grams.fmt()}g", fontSize = 22.sp, fontWeight = FontWeight.Black, color = Color.White)
        Text(label, color = TextDim, fontSize = 13.sp)
        Spacer(Modifier.height(10.dp))
        LinearProgressIndicator(
            progress = { (grams / goal).toFloat().coerceIn(0f, 1f) },
            modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
            color = color, trackColor = Color.White.copy(alpha = 0.08f)
        )
        Spacer(Modifier.height(6.dp))
        Text("$pct% daily", color = TextDim, fontSize = 11.sp)
    }
}

@Composable
fun StatRow(label: String, value: String, color: Color = Color.White) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = TextDim)
        Text(value, color = color, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun HealthScoreBar(score: Int) {
    val color = when {
        score >= 8 -> Accent
        score >= 5 -> CarbsColor
        else -> ErrorColor
    }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text("Health score", color = TextDim, modifier = Modifier.weight(1f))
        Text("$score/10", color = color, fontWeight = FontWeight.Black, fontSize = 18.sp)
    }
    Spacer(Modifier.height(8.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        repeat(10) { i ->
            Box(
                Modifier.weight(1f).height(8.dp).clip(RoundedCornerShape(4.dp))
                    .background(if (i < score) color else Color.White.copy(alpha = 0.08f))
            )
        }
    }
}

@Composable
fun LegendDot(label: String, color: Color, value: String) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 4.dp)) {
        Box(Modifier.size(10.dp).clip(CircleShape).background(color))
        Spacer(Modifier.width(8.dp))
        Column {
            Text(value, color = Color.White, fontWeight = FontWeight.Bold)
            Text(label, color = TextDim, fontSize = 12.sp)
        }
    }
}
