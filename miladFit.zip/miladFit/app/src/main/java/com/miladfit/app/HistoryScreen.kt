package com.miladfit.app

import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun HistoryScreen(history: List<HistoryEntry>, onClear: () -> Unit) {
    val zone = ZoneId.systemDefault()
    val today = history.filter { Instant.ofEpochMilli(it.timestamp).atZone(zone).toLocalDate() == LocalDate.now() }
    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            GradientTitle("History", 32.sp)
            Spacer(Modifier.weight(1f))
            if (history.isNotEmpty()) IconButton(onClick = onClear) { Icon(Icons.Filled.Delete, "Clear", tint = TextDim) }
        }
        Spacer(Modifier.height(12.dp))
        GlassCard(Modifier.fillMaxWidth().float3D(amplitude = 3f)) {
            Text("Today", color = TextDim)
            Text("${today.sumOf { it.result.calories }} kcal", color = Accent, fontSize = 30.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                LegendDot("Protein", ProteinColor, "${today.sumOf { it.result.protein }.fmt()} g")
                LegendDot("Carbs", CarbsColor, "${today.sumOf { it.result.carbs }.fmt()} g")
                LegendDot("Fat", FatColor, "${today.sumOf { it.result.fat }.fmt()} g")
            }
        }
        Spacer(Modifier.height(14.dp))
        if (history.isEmpty()) {
            Box(Modifier.fillMaxWidth().padding(top = 60.dp), contentAlignment = Alignment.Center) {
                Text("No meals yet. Scan your first one!", color = TextDim)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(history, key = { it.timestamp }) { HistoryRow(it) }
                item { Spacer(Modifier.height(16.dp)) }
            }
        }
    }
}

private val timeFmt = DateTimeFormatter.ofPattern("MMM d · HH:mm", Locale.US)

@Composable
private fun HistoryRow(entry: HistoryEntry) {
    val thumb = remember(entry.imagePath) {
        runCatching { BitmapFactory.decodeFile(entry.imagePath)?.asImageBitmap() }.getOrNull()
    }
    GlassCard(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            val shape = RoundedCornerShape(14.dp)
            if (thumb != null) {
                Image(thumb, null, Modifier.size(58.dp).clip(shape), contentScale = ContentScale.Crop)
            } else {
                Box(Modifier.size(58.dp).clip(shape).background(Color.White.copy(alpha = 0.06f)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Filled.Restaurant, null, tint = TextDim)
                }
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(entry.result.foodName, color = Color.White, fontWeight = FontWeight.Bold, maxLines = 1)
                Text(timeFmt.format(Instant.ofEpochMilli(entry.timestamp).atZone(ZoneId.systemDefault())), color = TextDim, fontSize = 12.sp)
                Text(
                    "P ${entry.result.protein.fmt()}g · C ${entry.result.carbs.fmt()}g · F ${entry.result.fat.fmt()}g",
                    color = TextDim, fontSize = 12.sp
                )
            }
            Text("${entry.result.calories}\nkcal", color = Accent, fontWeight = FontWeight.Black, fontSize = 15.sp)
        }
    }
}
