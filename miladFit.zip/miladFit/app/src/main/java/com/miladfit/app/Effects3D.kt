package com.miladfit.app

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/** Drag to rotate in 3D with perspective, springs back on release. */
fun Modifier.tilt3D(maxAngle: Float = 18f): Modifier = composed {
    val rx = remember { Animatable(0f) }
    val ry = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current.density
    val release = {
        scope.launch { rx.animateTo(0f, spring(dampingRatio = 0.35f, stiffness = 120f)) }
        scope.launch { ry.animateTo(0f, spring(dampingRatio = 0.35f, stiffness = 120f)) }
        Unit
    }
    pointerInput(Unit) {
        detectDragGestures(
            onDragEnd = { release() },
            onDragCancel = { release() },
        ) { change, drag ->
            change.consume()
            scope.launch {
                rx.snapTo((rx.value - drag.y / 6f).coerceIn(-maxAngle, maxAngle))
                ry.snapTo((ry.value + drag.x / 6f).coerceIn(-maxAngle, maxAngle))
            }
        }
    }.graphicsLayer {
        rotationX = rx.value
        rotationY = ry.value
        cameraDistance = 14f * density
    }
}

/** Card flips up from the floor in 3D when it enters. */
fun Modifier.flipIn(delayMs: Int = 0): Modifier = composed {
    val rot = remember { Animatable(75f) }
    val density = LocalDensity.current.density
    LaunchedEffect(Unit) {
        delay(delayMs.toLong())
        rot.animateTo(0f, spring(dampingRatio = 0.55f, stiffness = 160f))
    }
    graphicsLayer {
        rotationX = rot.value
        alpha = (1f - rot.value / 75f).coerceIn(0f, 1f)
        cameraDistance = 16f * density
    }
}

/** Gentle idle 3D sway. */
fun Modifier.float3D(amplitude: Float = 5f, periodMs: Int = 3800): Modifier = composed {
    val inf = rememberInfiniteTransition(label = "float")
    val a by inf.animateFloat(
        -amplitude, amplitude,
        infiniteRepeatable(tween(periodMs, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "a"
    )
    val density = LocalDensity.current.density
    graphicsLayer {
        rotationY = a
        rotationX = a / 2f
        cameraDistance = 16f * density
    }
}

/** 3D glowing sphere with protein / carbs / fat "electrons" orbiting on tilted planes. */
@Composable
fun NutritionOrb3D(modifier: Modifier = Modifier, size: Dp = 240.dp) {
    val colors = listOf(ProteinColor, CarbsColor, FatColor)
    val inf = rememberInfiniteTransition(label = "orb")
    val t by inf.animateFloat(0f, 360f, infiniteRepeatable(tween(8000, easing = LinearEasing)), label = "t")
    val pulse by inf.animateFloat(
        0.95f, 1.05f, infiniteRepeatable(tween(1600, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "p"
    )
    Canvas(modifier.size(size)) {
        val c = center
        val dim = this.size.minDimension
        val r = dim * 0.22f * pulse
        val orbit = dim * 0.44f
        val squash = 0.30f
        val tilts = floatArrayOf(-25f, 35f, 95f)

        fun dot(i: Int): Pair<Offset, Float> {
            val a = (t * (1f + i * 0.4f) + i * 120f) * PI / 180.0
            val x = orbit * cos(a).toFloat()
            val y = orbit * squash * sin(a).toFloat()
            val tr = tilts[i] * PI.toFloat() / 180f
            return Offset(c.x + x * cos(tr) - y * sin(tr), c.y + x * sin(tr) + y * cos(tr)) to sin(a).toFloat()
        }

        drawCircle(
            Brush.radialGradient(listOf(Accent.copy(alpha = 0.25f), Color.Transparent), center = c, radius = dim * 0.5f),
            radius = dim * 0.5f, center = c
        )
        tilts.forEachIndexed { i, deg ->
            rotate(deg, c) {
                drawOval(
                    colors[i].copy(alpha = 0.35f),
                    topLeft = Offset(c.x - orbit, c.y - orbit * squash),
                    size = Size(orbit * 2, orbit * squash * 2),
                    style = Stroke(1.5.dp.toPx())
                )
            }
        }
        val dots = colors.indices.map { dot(it) }
        // Electrons behind the sphere
        dots.forEachIndexed { i, (p, depth) ->
            if (depth < 0) drawCircle(colors[i].copy(alpha = 0.45f), radius = 5.dp.toPx(), center = p)
        }
        // Sphere with off-center light source = 3D shading
        drawCircle(
            Brush.radialGradient(
                listOf(Color.White, Accent, Color(0xFF1B6B2E), Color(0xFF0B2A14)),
                center = Offset(c.x - r * 0.4f, c.y - r * 0.45f), radius = r * 1.9f
            ),
            radius = r, center = c
        )
        drawCircle(Color.White.copy(alpha = 0.35f), radius = r * 0.16f, center = Offset(c.x - r * 0.38f, c.y - r * 0.42f))
        // Electrons in front
        dots.forEachIndexed { i, (p, depth) ->
            if (depth >= 0) {
                drawCircle(colors[i].copy(alpha = 0.25f), radius = 14.dp.toPx(), center = p)
                drawCircle(colors[i], radius = 7.dp.toPx() * (0.8f + 0.2f * depth), center = p)
            }
        }
    }
}

/** Animated scanning laser over the food photo. */
@Composable
fun ScanOverlay(modifier: Modifier = Modifier) {
    val inf = rememberInfiniteTransition(label = "scan")
    val f by inf.animateFloat(
        0f, 1f, infiniteRepeatable(tween(1600, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "f"
    )
    Canvas(modifier) {
        val step = size.width / 8f
        for (i in 1 until 8) {
            drawLine(Color.White.copy(alpha = 0.06f), Offset(step * i, 0f), Offset(step * i, size.height))
            drawLine(Color.White.copy(alpha = 0.06f), Offset(0f, step * i), Offset(size.width, step * i))
        }
        val y = size.height * f
        val band = 80.dp.toPx()
        drawRect(
            Brush.verticalGradient(listOf(Color.Transparent, Accent.copy(alpha = 0.35f), Color.Transparent), startY = y - band, endY = y + band),
            topLeft = Offset(0f, y - band), size = Size(size.width, band * 2)
        )
        drawLine(Accent, Offset(0f, y), Offset(size.width, y), strokeWidth = 3.dp.toPx())
    }
}
