package com.miladfit.app

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel

enum class Screen { Home, History, Settings }

@Composable
fun MiladFitApp(vm: MainViewModel = viewModel()) {
    val context = LocalContext.current
    val state by vm.state.collectAsState()
    var screen by rememberSaveable { mutableStateOf(Screen.Home) }
    var pendingUri by rememberSaveable { mutableStateOf<Uri?>(null) }

    val takePhoto = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok) pendingUri?.let(vm::analyzeUri)
    }
    val pickPhoto = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        uri?.let(vm::analyzeUri)
    }

    BackHandler(enabled = screen != Screen.Home) { screen = Screen.Home }
    BackHandler(enabled = screen == Screen.Home && state !is UiState.Idle) { vm.reset() }

    Box(Modifier.fillMaxSize().background(Bg)) {
        // Ambient neon glows
        Canvas(Modifier.fillMaxSize()) {
            drawCircle(
                Brush.radialGradient(listOf(Accent.copy(alpha = 0.12f), Color.Transparent), center = Offset(size.width * 0.1f, size.height * 0.1f), radius = size.width * 0.8f),
                radius = size.width * 0.8f, center = Offset(size.width * 0.1f, size.height * 0.1f)
            )
            drawCircle(
                Brush.radialGradient(listOf(ProteinColor.copy(alpha = 0.10f), Color.Transparent), center = Offset(size.width, size.height * 0.85f), radius = size.width * 0.9f),
                radius = size.width * 0.9f, center = Offset(size.width, size.height * 0.85f)
            )
        }
        Scaffold(
            containerColor = Color.Transparent,
            bottomBar = {
                NavigationBar(containerColor = SurfaceColor.copy(alpha = 0.92f)) {
                    listOf(
                        Triple(Screen.Home, "Scan", Icons.Filled.PhotoCamera),
                        Triple(Screen.History, "History", Icons.Filled.History),
                        Triple(Screen.Settings, "Settings", Icons.Filled.Settings),
                    ).forEach { (s, label, icon) ->
                        NavigationBarItem(
                            selected = screen == s,
                            onClick = { screen = s },
                            icon = { Icon(icon, label) },
                            label = { Text(label) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Color.Black, indicatorColor = Accent,
                                selectedTextColor = Accent, unselectedIconColor = TextDim, unselectedTextColor = TextDim
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) {
                when (screen) {
                    Screen.Home -> HomeScreen(
                        state = state,
                        onCamera = {
                            val uri = ImageUtils.newCameraUri(context)
                            pendingUri = uri
                            takePhoto.launch(uri)
                        },
                        onGallery = {
                            pickPhoto.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                        },
                        onReset = vm::reset
                    )
                    Screen.History -> HistoryScreen(vm.history, vm::clearHistory)
                    Screen.Settings -> SettingsScreen(vm.apiKey, vm::updateApiKey)
                }
            }
        }
    }
}
