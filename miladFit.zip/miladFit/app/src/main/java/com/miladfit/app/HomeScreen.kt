package com.miladfit.app

import android.graphics.Bitmap
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun HomeScreen(state: UiState, onCamera: () -> Unit, onGallery: () -> Unit, onReset: () -> Unit) {
    AnimatedContent(
        targetState = state,
        contentKey = { it::class },
        transitionSpec = { (fadeIn(tween(450)) + scaleIn(initialScale = 0.92f)) togetherWith fadeOut(tween(200)) },
        label = "home"
    ) { s ->
        when (s) {
            is UiState.Idle -> IdleContent(onCamera, onGallery)
            is UiState.Analyzing -> AnalyzingContent(s.image)
            is UiState.Success -> ResultContent(s.image, s.result, onReset)
            is UiState.Error -> ErrorContent(s.image, s.message, onReset)
        }
    }
}

@Composable
private fun IdleContent(onCamera: () -> Unit, onGallery: () -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(16.dp))
        GradientTitle("miladFit", 46.sp)
        Text("Snap your meal. Know your macros.", color = TextDim, fontSize = 15.sp)
        Spacer(Modifier.height(12.dp))
        NutritionOrb3D(Modifier.tilt3D(), size = 270.dp)
        Text("drag the orb ✦", color = TextDim.copy(alpha = 0.6f), fontSize = 12.sp)
        Spacer(Modifier.height(18.dp))
        GlassCard(Modifier.fillMaxWidth().float3D(amplitude = 3f)) {
            Feature(Icons.Filled.AutoAwesome, "AI food recognition", "Detects every item on your plate")
            Feature(Icons.Filled.Insights, "Full macro breakdown", "Calories, protein, carbs, fat & more")
            Feature(Icons.Filled.Speed, "Results in seconds", "Powered by Google Gemini Vision")
        }
        Spacer(Modifier.height(22.dp))
        PrimaryButton("Take a Photo", Icons.Filled.PhotoCamera, onClick = onCamera)
        Spacer(Modifier.height(12.dp))
        SecondaryButton("Choose from Gallery", Icons.Filled.PhotoLibrary, onClick = onGallery)
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun Feature(icon: ImageVector, title: String, subtitle: String) {
    Row(Modifier.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(Accent.copy(alpha = 0.15f)),
            contentAlignment = Alignment.Center
        ) { Icon(icon, null, tint = Accent) }
        Spacer(Modifier.width(14.dp))
        Column {
            Text(title, color = Color.White, fontWeight = FontWeight.Bold)
            Text(subtitle, color = TextDim, fontSize = 13.sp)
        }
    }
}

@Composable
private fun AnalyzingContent(image: Bitmap) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        val shape = RoundedCornerShape(28.dp)
        Box(
            Modifier.fillMaxWidth().aspectRatio(1f).float3D(amplitude = 6f)
                .clip(shape).border(2.dp, Accent.copy(alpha = 0.6f), shape)
        ) {
            Image(image.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            ScanOverlay(Modifier.matchParentSize())
        }
        Spacer(Modifier.height(28.dp))
        CircularProgressIndicator(color = Accent)
        Spacer(Modifier.height(16.dp))
        Text("Analyzing your meal…", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        Text("Detecting ingredients, portions & macros", color = TextDim)
    }
}

@Composable
private fun ResultContent(image: Bitmap, r: NutritionResult, onReset: () -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Spacer(Modifier.height(4.dp))
        Box(Modifier.fillMaxWidth().height(250.dp).flipIn(0).clip(RoundedCornerShape(28.dp))) {
            Image(image.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            Box(Modifier.matchParentSize().background(Brush.verticalGradient(listOf(Color.Transparent, Bg.copy(alpha = 0.95f)))))
            Column(Modifier.align(Alignment.BottomStart).padding(18.dp)) {
                Text(r.foodName, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Black)
                if (r.description.isNotBlank()) Text(r.description, color = TextDim, fontSize = 13.sp)
                Spacer(Modifier.height(6.dp))
                Text(
                    "${r.confidence}% confidence",
                    color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(Accent).padding(horizontal = 8.dp, vertical = 3.dp)
                )
            }
        }

        GlassCard(Modifier.fillMaxWidth().flipIn(120)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                MacroRing(r.calories, r.protein, r.carbs, r.fat, Modifier.tilt3D(), size = 170.dp)
                Spacer(Modifier.width(16.dp))
                Column {
                    LegendDot("Protein", ProteinColor, "${r.protein.fmt()} g")
                    LegendDot("Carbs", CarbsColor, "${r.carbs.fmt()} g")
                    LegendDot("Fat", FatColor, "${r.fat.fmt()} g")
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(
                "${(r.calories * 100 / DailyGoals.CALORIES)}% of a ${DailyGoals.CALORIES} kcal day",
                color = TextDim, fontSize = 12.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center
            )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MacroCard("Protein", r.protein, ProteinColor, DailyGoals.PROTEIN, Modifier.weight(1f).flipIn(220))
            MacroCard("Carbs", r.carbs, CarbsColor, DailyGoals.CARBS, Modifier.weight(1f).flipIn(300))
            MacroCard("Fat", r.fat, FatColor, DailyGoals.FAT, Modifier.weight(1f).flipIn(380))
        }

        GlassCard(Modifier.fillMaxWidth().flipIn(460)) {
            Text("More nutrients", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Spacer(Modifier.height(6.dp))
            StatRow("Fiber", "${r.fiber.fmt()} g")
            StatRow("Sugar", "${r.sugar.fmt()} g")
            StatRow("Sodium", "${r.sodiumMg} mg")
            Spacer(Modifier.height(10.dp))
            HealthScoreBar(r.healthScore)
        }

        if (r.items.isNotEmpty()) {
            GlassCard(Modifier.fillMaxWidth().flipIn(540)) {
                Text("What's on your plate", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Spacer(Modifier.height(6.dp))
                r.items.forEach { item ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(item.name, color = Color.White)
                            Text("${item.grams} g", color = TextDim, fontSize = 12.sp)
                        }
                        Text("${item.calories} kcal", color = Accent, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        if (r.tip.isNotBlank()) {
            GlassCard(Modifier.fillMaxWidth().flipIn(620)) {
                Row(verticalAlignment = Alignment.Top) {
                    Icon(Icons.Filled.Lightbulb, null, tint = CarbsColor)
                    Spacer(Modifier.width(10.dp))
                    Text(r.tip, color = Color.White, fontSize = 14.sp)
                }
            }
        }

        Text(
            "AI estimates. Real values can vary by ±15%.",
            color = TextDim.copy(alpha = 0.7f), fontSize = 11.sp,
            modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center
        )
        PrimaryButton("Scan Another Meal", Icons.Filled.PhotoCamera, onClick = onReset)
        Spacer(Modifier.height(20.dp))
    }
}

@Composable
private fun ErrorContent(image: Bitmap?, message: String, onReset: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        if (image != null) {
            Image(
                image.asImageBitmap(), null,
                Modifier.size(160.dp).float3D().clip(RoundedCornerShape(24.dp)),
                contentScale = ContentScale.Crop
            )
            Spacer(Modifier.height(20.dp))
        }
        Icon(Icons.Filled.ErrorOutline, null, tint = ErrorColor, modifier = Modifier.size(48.dp))
        Spacer(Modifier.height(10.dp))
        Text("Hmm, something went wrong", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        Spacer(Modifier.height(6.dp))
        Text(message, color = TextDim, textAlign = TextAlign.Center)
        Spacer(Modifier.height(24.dp))
        PrimaryButton("Try Again", Icons.Filled.Refresh, onClick = onReset)
    }
}
