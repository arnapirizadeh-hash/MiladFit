# miladFit 🍏

**Snap a photo of your meal → get calories, protein, carbs, fat, fiber, sugar, sodium and a health score in seconds.**

Built with Kotlin + Jetpack Compose, featuring a 3D UI (draggable orbiting nutrition orb, perspective tilt, flip-in cards, scanning laser) and Google Gemini Vision for food recognition.

## Features
- 📸 Camera or gallery input
- 🤖 AI recognition of every item on the plate with portion estimates
- 🔥 Animated calorie ring with macro split
- 🧊 3D effects: drag-to-rotate orb, tilt cards, flip-in result cards
- 📊 Daily value bars + health score + nutrition tip
- 🕘 History with today's totals (stored on device)

## Get the APK with GitHub (no PC setup needed)
1. Create a new repo on GitHub named `miladFit` and upload all these files (keep the folder structure, including `.github/`). **Do not upload `local.properties` to a public repo.**
2. Go to the **Actions** tab → the "Build miladFit APK" workflow runs automatically.
3. When it's green, open the run → download the **miladFit-apk** artifact → install `app-release.apk` on your phone.
4. Open the app → **Settings** → paste a free Gemini key from https://aistudio.google.com/apikey. This project also includes your current key in `local.properties` for local builds, but that file is intentionally ignored by Git.

Optional: add the key as a repo secret `GEMINI_API_KEY` (Settings → Secrets → Actions) to bake it into the build.
Push a tag like `v1.0.0` to auto-publish a GitHub Release with the APK.

## Build locally
Open the folder in Android Studio (Koala or newer), or add `GEMINI_API_KEY=your_key` to `local.properties` and run.

## Tech
Kotlin 2.0 · Jetpack Compose (Material 3) · MVVM · Coroutines · Gemini 2.5 Flash REST API · minSdk 28
